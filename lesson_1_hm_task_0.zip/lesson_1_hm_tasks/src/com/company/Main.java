package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        /*
        Task-1:
        Create 3 variables to store your age, height,and weight and print them using println.
        myAge, myHeight and myWeight
         */
        int myAge;
        double myHeight;
        double myWeight;
        /*
        TASK-2 part1:
        Using java calculate the person's body massindex and print the result with differentexamples.
         */
        System.out.println("Body Mass Index is a simple calculationusing a person's height and weight.");
        System.out.println("Theformula is BMI = kg/m2 where kg is a person'sweight in kilograms and m2 is their height in metres squared.");
        System.out.println("Please enter you Age:");
        Scanner console = new Scanner(System.in);
        myAge = console.nextInt();
        System.out.println("Please enter you Height in sm:");
        myHeight = console.nextDouble();
        System.out.println("Please enter you Weight in kilogram:");
        myWeight = console.nextDouble();
        double BMI = myWeight / Math.pow((myHeight / 100), 2);
        System.out.println("Your Age is " + myAge + " and Body Mass Index is " + BMI );
        /*
        TASK-3:
        Write the java program that converts givenkilogram values to pounds and grams.NOTE: for an approximate result of kg to pount,multiply the mass value by 2.205
         */
        double pounds = myWeight * 2.205;
        System.out.println("Your Weight in pounds is: " + pounds);
        double grams = myWeight * 1000;
        System.out.println("Your Weight in grams is: " + grams);
        /*
        TASK-4:
        Write the java program that converts given meter values to the foot and centimeter.
        NOTE: for an approximate result of Meter tofoot, multiply the length value by 3.281
         */
        System.out.println(" ");
        System.out.println("There is a Converter is running");
        double meter;
        System.out.println("Please add any Value in meter:");
        meter = console.nextInt();
        double foot = meter * 3.281;
        System.out.println("It is equal to " + foot + " in foots");
        double centimeter = meter * 100;
        System.out.println("It is equal to " + (int) centimeter + " in centimeters");
        /*
        TASK-5:
        Write a Java program that reads a number in inches, converts it to meters.
        Note: One inch is 0.0254 meters.
         */
        double inches;
        System.out.println(" ");
        System.out.println("Please any value in inches:");
        inches = console.nextDouble();
        meter = inches * 0.0254;
        System.out.println("It is equal to " + meter + " in meter");
        /*
        TASK-6:
        Write a Java program to convert temperaturefrom Fahrenheit to Celsius degree.
        212.0 degree Fahrenheit is equal to 100.0 in Celsius
         */
        double fahrenheit;
        System.out.println(" ");
        System.out.println("Input a degree in Fahrenheit:");
        fahrenheit = console.nextInt() ;
        double celsius = (fahrenheit -32) * 5 / 9;
        System.out.println("It is equal to " + (int)celsius + " in Celsuis");

    }
}
